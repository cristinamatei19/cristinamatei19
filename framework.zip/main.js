const createCard = (imgPath,cardTitle,cardDescription,buttonText, parentElement) => {
    // card
    const card = document.createElement("div");
    // img
    const cardImage = document.createElement('img');
    cardImage.src = imgPath;
    // card-body
    const cardBody = document.createElement("div");
    // title
    const cardTitleWrapper = document.createElement('h1');
    const cardTitleElement = document.createTextNode(cardTitle);
    // description
    const cardDescWrapper = document.createElement('p');
    const cardDescElement = document.createTextNode(cardDescription);


    // CSS classes
    card.classList.add('card');
    cardBody.classList.add('card-body');
    cardImage.classList.add('card-image');



    // appends
    card.appendChild(cardImage);
    card.appendChild(cardBody);
    cardBody.appendChild(cardTitleWrapper);
    cardBody.appendChild(cardDescWrapper)
    cardTitleWrapper.appendChild(cardTitleElement);
    cardDescWrapper.appendChild(cardDescElement);
    // button
    createButton(buttonText,cardBody);

    parentElement.appendChild(card);
}

const createButton = (buttonText, parentElement) => {
    const button = document.createElement('button');
    const buttonTextElement = document.createTextNode(buttonText);

    button.classList.add('btn');
    button.classList.add('theme-primary');

    button.appendChild(buttonTextElement);

    parentElement.appendChild(button);
}
const createWrapper = (elementName,parentElement) => {
    const wrapper = document.createElement('div');
    wrapper.classList.add(elementName+'-wrapper');
    parentElement.appendChild(wrapper);
}

const createCards = (parentElement) => {
    createWrapper('card',parentElement);
    createCard('Ex1.jpg','hello','Lorem ipsum','Test Button', document.querySelector('.card-wrapper'));
    createCard('Ex1.jpg','hello','Lorem ipsum','Test Button', document.querySelector('.card-wrapper'));
    createCard('Ex1.jpg','hello','Lorem ipsum','Test Button', document.querySelector('.card-wrapper'));
    createCard('Ex1.jpg','hello','Lorem ipsum','Test Button', document.querySelector('.card-wrapper'));
}
const createButtons = (parentElement) => {
    createWrapper('button', parentElement);
    createButton('Sunt in wrapper', document.querySelector('.button-wrapper'));
    createButton('Sunt in wrapper', document.querySelector('.button-wrapper'));
    createButton('Sunt in wrapper', document.querySelector('.button-wrapper'));
    createButton('Sunt in wrapper', document.querySelector('.button-wrapper'));
    createButton('Sunt in wrapper', document.querySelector('.button-wrapper'));
}


// Ne creem pagina web
const createPage = () => {
    createCards(document.body);
    createButtons(document.body);
    createWrapper('second-card',document.body);
    createCard('Ex1.jpg','hello','Lorem ipsum','Test Button', document.querySelector('.second-card-wrapper'));
}



document.body.onload = createPage();