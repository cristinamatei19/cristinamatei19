import './App.css';
import Game from './Components/Game/Game';

function App() {
  return (
    <div className="App">
      <div className="App-content">
        <Game />
      </div>
    </div>
  );
}

export default App;
