import './Game.css';
import Card from '../Card/Card';
import Deck from '../Deck/Deck';
import axios from 'axios';
import { useState } from 'react';

const Game = () => {
    const [deck, setDeck] = useState({});
    const [card, setCard] = useState({});

    const createDeck = () => {
        axios.get("https://deckofcardsapi.com/api/deck/new/").then((res) => {
            axios.get(`https://deckofcardsapi.com/api/deck/${res.data.deck_id}/shuffle/`)
            setDeck(res.data);
            setCard({});
        })
    }

    const drawCard = () => {
        axios.get(`https://deckofcardsapi.com/api/deck/${deck.deck_id}/draw/?count=1`).then((res) => {
            let newDeck = {};
            newDeck.deck_id = res.data.deck_id;
            newDeck.remaining = res.data.remaining;
            setDeck(newDeck);
            setCard(res.data.cards[0]);
        })
    }


    return (
        <div className='game'>
            {deck.remaining >= 0 ?
                <>
                    <div className='d-flex flex-row'>
                        {deck.remaining > 0 ?
                        <Deck />
                        :
                        ""
                        }
                        {card.images?.png ?
                            <Card card={card} />
                            :
                            ""
                        }
                    </div>
                    {deck.remaining === 0 ?
                    <button onClick={() => createDeck()} className='btn btn-success'>
                        Create deck
                    </button>
                    :
                    <button onClick={() => drawCard()} className='btn btn-success'>
                        Draw
                    </button>
                    }
                </>
                :
                <button onClick={() => createDeck()} className='btn btn-success'>
                    Create deck
                </button>
            }
        </div>
    )
}

export default Game;