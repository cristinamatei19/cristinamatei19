import './Card.css';

const Card = ({card}) => {
    return (
        <>
            <img className='card img-fluid ms-3' src={card.images.png} alt='' />
        </>
    )
}

export default Card;