import './Deck.css';
import deckImage from '../../assets/images/back.png';

const Deck = () => {
    return (
        <>
            <img className='card-back img-fluid' src={deckImage} alt='' />
        </>
    )
}

export default Deck;