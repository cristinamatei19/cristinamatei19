import './App.css';
import Main from './Pages/Main';
import Auth from './Pages/Auth';
import { useSelector } from 'react-redux';

function App() {
  const isLogged = useSelector((state) => state.auth.isLogged);

  return (
    <div className="App">

        {isLogged ?
          <div id='AppDiv' className="App-div">
            <Main />
          </div>
          :
          <div id='AppDiv' className="App-div justify-content-center">
            <Auth />
          </div>}
    </div>
  );
}

export default App;
