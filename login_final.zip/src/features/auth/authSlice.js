import { createSlice } from '@reduxjs/toolkit'

export const authSlice = createSlice({
  name: 'auth',
  initialState: {
    isLogged: false,
    trials: 0,
    username: 'admin',
    password: 'admin'
  },
  reducers: {
    log_in: (state, action) => {
        if(action.payload.username === state.username && action.payload.password === state.password) {
            state.isLogged = true;
            state.trials = 0;
        } else {
            state.trials++;
        }
    },
    sign_out: (state) => {
        state.isLogged = false;
        state.trials = 0;
    }
  },
})

export const { log_in, sign_out } = authSlice.actions

export default authSlice.reducer