import './Content.css';

const Content = () => {
    return (
        <main>
            <h1 className='text-center p-5 m-5'>This is the content</h1>
        </main>
    )
}

export default Content;