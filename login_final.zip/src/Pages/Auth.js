import Login from "../Components/Login/Login";

const Auth = () => {
    return (
        <Login />
    )
}

export default Auth;