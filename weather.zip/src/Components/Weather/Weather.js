import './Weather.css';
import axios from 'axios';
import { useState, useEffect } from 'react';
import Day from './Day/Day';

const Weather = () => {
    const [forecast, setForecast] = useState([]);

    useEffect(() => {
        axios.get('https://api.weatherapi.com/v1/forecast.json?key=bc2a830e9e38442f84d65658233007&q=Bucharest&days=3')
        .then(res => {
            setForecast(res.data.forecast.forecastday)
        })
    },[]);

    return (
        <div className='d-flex flex-row flex-nowrap justify-content-center align-items-center'>
            {forecast.length > 0 &&
                forecast.map((day, index) => (
                    <Day day={day} key={index} />
                ))
            }
        </div>
    )
}

export default Weather;