import './Day.css';

const Day = ({day}) => {
    console.log(day);
    return (
        <div className='weather-card d-flex flex-column justify-content-center align-items-center mx-5'>
            <div className='date-container d-flex flex-column justify-content-center align-items-center my-3'>
                {day.date}
            </div>
            <div className='weather-conditions d-flex flex-column justify-content-center align-items-center my-3'>
                <p>{day.day.condition.text}</p>
                <img src={day.day.condition.icon} alt='' />
            </div>
            <div className='weather-specs d-flex flex-column justify-content-center my-3'>
                <p>Avg. Temp: {day.day.avgtemp_c}</p>
                <p>Avg. Wind speed: {day.day.avgvis_km}</p>
                <p>Barbecue time: {day.day.avgtemp_c > 25 ? 'Yes :)' : 'No :('}</p>
            </div>
        </div>
    )
}

export default Day;