import { createSlice } from '@reduxjs/toolkit'

export const authSlice = createSlice({
  name: 'auth',
  initialState: {
    trials: 0,
    username: 'admin',
    password: 'admin',
    fullname: 'George Dumitrache',
    email: 'email@email'
  },
  reducers: {
    log_in: (state, action) => {
        if(action.payload.username === state.username && action.payload.password === state.password) {
            localStorage.setItem("isLogged", true);
            document.cookie = 'isLogged=true';
            state.trials = 0;
        } else {
            state.trials++;
        }
    },
    sign_out: (state) => {
        localStorage.setItem('isLogged', false)
        window.location.reload();
        state.trials = 0;
    },
    set_fullname: (state,action) => {
        state.fullname = action.payload;
    },
    set_email: (state,action) => {
        state.email = action.payload;
    },
    set_password: (state,action) => {
        state.password = action.payload;
    },
  },
})

export const { log_in, sign_out, set_fullname, set_email, set_password } = authSlice.actions

export default authSlice.reducer