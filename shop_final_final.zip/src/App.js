import './App.css';

function App() {
  return (
    <>
    {/* Silence is golden. */}
    </>
  );
}

export default App;
