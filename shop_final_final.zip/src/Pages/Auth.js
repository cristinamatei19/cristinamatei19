import Login from "../Components/Login/Login";

const Auth = () => {
    return (
        <div className="App">
            <div id='AppDiv' className="App-div justify-content-center">
                <Login />
            </div>
        </div>

    )
}

export default Auth;