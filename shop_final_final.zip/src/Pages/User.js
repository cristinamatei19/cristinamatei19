import Header from "../Components/Header/Header";
import UserDetails from "../Components/UserDetails/UserDetails";

const User = () => {
    return (
        <div className="App">
            <div id='AppDiv' className="App-div">
                <Header />
                <UserDetails />
            </div>
        </div>
    )
}
export default User;