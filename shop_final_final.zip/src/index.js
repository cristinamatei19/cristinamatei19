import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import reportWebVitals from './reportWebVitals';
import { store } from './features/store';
import { Provider } from 'react-redux';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import User from './Pages/User';
import Main from './Pages/Main';
import Auth from './Pages/Auth';
import PrivateRoute from './routes/PrivateRoot';

/*
Proiecte pe care React Router straluceste:
- Site-uri de Ecommerce(pe partea de filtre), e bun fiindca user-ului isi poate face bookmark pe filtre
- Site-uri de booking, aceasi regula cu filtrele
- + Orice site foloseste filtre, sau are multe pagini
Proiecte unde nu este nevoie de React Router:
- Tools-uri mici/medii
- Aplicatii cu scop de prezentare
- Aplicatii heavy(foarte foarte heavy) in animatii, ThreeJS, PixiJS
*/

const router = createBrowserRouter([
  {
    path: "/",
    element: <PrivateRoute><Main /></PrivateRoute>
  },
  {
    path: "/user",
    element: <PrivateRoute><User /></PrivateRoute> /* PrivateRoute ar trebui sa autentifice */
  },
  {
    path: "/login",
    element: <Auth />
  }
]);


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Provider store={store}>
        <RouterProvider router={router} />
    </Provider>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
