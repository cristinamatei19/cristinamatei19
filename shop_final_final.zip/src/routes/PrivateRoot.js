import Auth from "../Pages/Auth";

const PrivateRoute = ({children}) => {
    const isLogged = localStorage.getItem("isLogged");

    if (isLogged === 'false') {
        return <Auth />;
    } else return children;
};

export default PrivateRoute;