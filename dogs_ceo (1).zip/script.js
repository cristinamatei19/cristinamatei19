// https://dog.ceo/api/breeds/list/all - Link-ul asta ne returneaza toate rasele si subrasele de caini
// https://dog.ceo/api/breed/hound/images - Link-ul asta ne returneaza imagini cu rasa aleasa (+subrase)
// https://dog.ceo/api/breed/hound/images/random
// https://dog.ceo/api/breed/hound/afghan/images - Link-ul asta ne returneaza imagini cu subrasa aleasa
// https://dog.ceo/api/breed/hound/afghan/images/random


// GET, POST, PUT, PATCH, DELETE
/*
GET - returnam date -> https://www.domeniu.com/ruta/variabilaCeMergeInBackend
POST - postam date -> https://www.domeniu.com/ruta
PUT, PATCH - updateaza date
DELETE - sterge date
*/

// trimitem scrisoare catre backend
axios.get('https://dog.ceo/api/breeds/list/all')
// primim raspuns de la scrisoare
.then(function (response) {
    /*
        obiect = {
            prop1: val1,
            prop2: val2,
            prop3: val3,
        } -> JSON
        JSON - JavaScript Object Notation
    */
    for(const key in response.data.message) {
        if(response.data.message[key].length === 0) {
            createBreedCard(key);
        } else {
            createSubreedCard(key, response.data.message[key]);
        }
    }
})
// daca nu ajunge scrisoare
.catch(function (error) {
    console.log(error);
})

function createBreedCard(breed) {
    console.log(breed);
    /*
    <div class='breed-card'>
        <h3>breedName</h3>
        <img src='breed.jpg' alt=''>
    </div>
    */
   const breedCard = document.createElement('div'); // <div></div>
   const breedNameWrapper = document.createElement('h3'); // <h3></h3>
   const breedName = document.createTextNode(breed);
   breedNameWrapper.appendChild(breedName);
   breedCard.appendChild(breedNameWrapper);
   breedCard.classList.add('breed-card');
   axios.get(`https://dog.ceo/api/breed/${breed}/images/random`)
   .then(function (response) {

   })
   .catch(function (error) {
    console.log(error);
   })


   document.getElementById('dogBreeds').appendChild(breedCard);
   /*
    <div>
        <h3>breedName</h3>
    </div>
    */
}
function createSubreedCard(breed, subreed) {
    console.log(breed);
    console.log(subreed);
}
