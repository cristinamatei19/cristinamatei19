class Player {
    constructor(money){
        this.monet = money;
    }
    buyFactory(nivel,moneyProducedPerMinute){
        const newFactory = new Factory(nivel,moneyProducedPerMinute);
        if(this.money = this.monet - newFactory.cost;
            new.Factory
            

    }
}

class Factory {
    constructor(nivel,moneyProducedPerMinute){
        this.nivel = nivel;
        this.moneyProducedPerMinute = moneyProducedPerMinute;
        this.cost = 400;
    }
    buildFactory(){
        const factoryImage = document.createElement('img');
        factoryImage.src = 'factory.png'
        const factoryDetails = document.createElement('div');
        const factoryLevels = document.createTextNode(this.nivel);
    }
}

const player = new Player(1000);
player.buyFactory(1,600);