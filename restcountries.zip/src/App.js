import './App.css';
import CountriesTable from './Components/CountriesTable/CountriesTable';

function App() {
  return (
    <div className="App">
      <div className="App-content">
        <h1>REST Countries</h1>
        <CountriesTable />
      </div>
    </div>
  );
}

export default App;
