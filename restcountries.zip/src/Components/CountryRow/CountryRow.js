import './CountryRow.css';

const CountryRow = ({country, setCountries, countries}) => {
    const removeCountry = (countryName) => {
        setCountries(countries.filter((country) => country.name.common !== countryName));
    }

    return (
        <tr>
            <td>{country.id}</td>
            <td>{country.name.common}</td>
            <td>{country.population}</td>
            <td>
                <button onClick={() => removeCountry(country.name.common)} className='btn btn-danger'>Remove</button>
            </td>
        </tr>
    )
}

export default CountryRow;