import './CountriesTable.css';
import CountryRow from '../CountryRow/CountryRow';
import axios from 'axios';
import { useState, useEffect } from 'react';

const CountriesTable = () => {

    const [countries, setCountries] = useState([]);


    // [] - array de dependinte. Toate variabilele de aici sunt urmarite de React
    // In momentul in care se schimba o variabila de aici, se ruleaza codul din arrow function
    // Daca nu avem nicio variabila, atunci ruleaza codul o singura data
    useEffect(() => {
        axios.get('https://restcountries.com/v3.1/all').then((res) => {
            // NU E GOOD PRACTICE SA ALOCAM ID-uri DIN FRONTEND!
            let countriesData = [];
            res.data.map((country, index) => {
                country.id = index;
                countriesData.push(country);
            })
            setCountries(countriesData);
        })
    },[]);

    return (
        <table>
            <thead>
                <tr>
                    <td>ID</td>
                    <td>Name</td>
                    <td>Population</td>
                    <td>Actions</td>
                </tr>
            </thead>
            <tbody>
                { countries &&
                    countries.map((country, index) => (
                        <CountryRow country={country} key={index} setCountries={setCountries} countries={countries} />
                    ))
                }
            </tbody>
        </table>
    )
}

export default CountriesTable;