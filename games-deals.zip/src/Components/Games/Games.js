import './Games.css';
import GameCards from './GameCards/GameCards';
import GameFilter from './GamesFilter/GameFilters';
import axios from 'axios';
import { useState, useEffect } from 'react';

const Games = () => {
    const [games, setGames] = useState([]);

    const getGames = (filter = '') => {
        axios.get(`https://www.cheapshark.com/api/1.0/games?title=${filter}`).then(res => setGames(res.data))
    }

    useEffect(() => getGames(), []);

    return (
        <div>
            <GameCards games={games} />
            <GameFilter games={games} getGames={getGames} />
        </div>
    )
}

export default Games;