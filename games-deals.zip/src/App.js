import './App.css';
import Header from './Components/Header/Header';
import Games from './Components/Games/Games';

function App() {
  return (
    <div className="App">
      <div className="App-content">
        <Header />
        <Games />
      </div>
    </div>
  );
}

export default App;
