import { createSlice } from '@reduxjs/toolkit'

export const pageSlice = createSlice({
  name: 'page',
  initialState: {
    page: 1
  },
  reducers: {
    set_page: (state, action) => {
        state.page = action.payload
    }
  },
})

export const { set_page } = pageSlice.actions

export default pageSlice.reducer