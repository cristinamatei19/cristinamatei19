import { createSlice } from '@reduxjs/toolkit'

export const productSlice = createSlice({
  name: 'product',
  initialState: [],
  reducers: {
    add_product: (state, action) => {
        state.push(action.payload)
    }
  },
})

export const { add_product } = productSlice.actions

export default productSlice.reducer