import { configureStore } from '@reduxjs/toolkit'
import authReducer from '../features/auth/authSlice'
import pageReducer from '../features/page/pageSlice'
import productReducer from '../features/product/productSlice'

export const store = configureStore({
  reducer: {
    auth: authReducer,
    page: pageReducer,
    product: productReducer,
  },
})