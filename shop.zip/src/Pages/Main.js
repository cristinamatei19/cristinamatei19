import Header from "../Components/Header/Header";
import Content from "../Components/Content/Content";

const Main = () => {
    return (
        <>
        <Header />
        <Content />
        </>
    )
}

export default Main;