import Header from "../Components/Header/Header";
import UserDetails from "../Components/UserDetails/UserDetails";

const User = () => {
    return (
        <>
            <Header />
            <UserDetails />
        </>
    )
}
export default User;