import './Header.css';
import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import { useDispatch } from 'react-redux';
import { sign_out } from '../../features/auth/authSlice';
import { set_page } from '../../features/page/pageSlice';
import axios from 'axios';

const Header = () => {
    // fe22cba98ba8847d4cfed2a9b6cc56d2
    axios.get('https://api.getfestivo.com/v2/holidays?country=US&year=2022&api_key=fe22cba98ba8847d4cfed2a9b6cc56d2').then(res => console.log(res.data))
    const dispatch = useDispatch();

    const signOut = () => {
        dispatch(sign_out());
    }
    const changePage = (newPage) => {
        dispatch(set_page(newPage))
    }

    return (
      <AppBar position="static">
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            News
          </Typography>
          <Button onClick={() => changePage(1)} color="inherit">Shop</Button>
          <Button onClick={() => changePage(2)} color="inherit">User</Button>
          <Button onClick={() => signOut()} color="inherit">Sign out</Button>
        </Toolbar>
      </AppBar>
    )
}

export default Header;