import './Content.css';
import { useRef, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { useSelector } from 'react-redux';
import Product from './Product/Product';

const Content = () => {
    const products = useSelector((state) => state.product)
    return (
        <main>
            <Canvas>
                <ambientLight />
                <pointLight position={[10, 10, 10]} />
                <ObjectRender objPos={[0, 0, 0]} />
            </Canvas>
            {products.map((product, key) => (
                <Product product={product} key={key} />
            ))}
        </main>
    )
}

const ObjectRender = ({objPos}) => {
    const meshRef = useRef()
    const [resize, setResize] = useState('inc');

    const [hovered, setHover] = useState(false)
    const [active, setActive] = useState(false)

    useFrame((state, delta) => (
        meshRef.current.rotation.x += delta
    ))
    useFrame((state,delta) => {
        resize === 'inc' ? meshRef.current.position.z += 0.05 : meshRef.current.position.z -= 0.05

        if(meshRef.current.position.z > 3)
            setResize('desc');
        if(meshRef.current.position.z < -3)
            setResize('inc');
    })

    return (
        <mesh
            position={objPos}
            ref={meshRef}
            scale={active ? 1.5 : 1}
            onClick={(event) => setActive(!active)}
            onPointerOver={(event) => setHover(true)}
            onPointerOut={(event) => setHover(false)}>
            <boxGeometry args={[1, 1, 1]} />
            <meshStandardMaterial color={hovered ? 'hotpink' : 'orange'} />
        </mesh>
    )
}

export default Content;