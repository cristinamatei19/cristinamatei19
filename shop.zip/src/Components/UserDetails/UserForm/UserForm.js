import './UserForm.css';
import TextField from '@mui/material/TextField';
import { useSelector, useDispatch } from 'react-redux';
import { set_fullname, set_email, set_password } from '../../../features/auth/authSlice';

const UserForm = () => {
    const user = useSelector((state) => state.auth)
    const dispatch = useDispatch();
    const changeName = (newName) => {
        dispatch(set_fullname(newName));
    }
    const changeEmail = (newEmail) => {
        dispatch(set_email(newEmail))
    }
    const changePassword = (newPass) => {
        dispatch(set_password(newPass))
    }

    return (
        <div className='d-flex justify-content-center align-items-center flex-column'>
            <TextField className='mb-3' id="outlined-basic" label="Name" onChange={(e) => changeName(e.target.value)} variant="outlined" value={user.fullname} />
            <TextField className='mb-3' id="outlined-basic" label="Email" onChange={(e) => changeEmail(e.target.value)} variant="outlined" value={user.email} />
            <TextField className='mb-3' id="outlined-basic" label="Password" onChange={(e) => changePassword(e.target.value)} variant="outlined" value={user.password} />
        </div>
    )
}

export default UserForm;