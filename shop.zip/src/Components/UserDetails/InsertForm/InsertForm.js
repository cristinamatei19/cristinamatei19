import './InsertForm.css';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { add_product } from '../../../features/product/productSlice';

const InsertForm = () => {
    const dispatch = useDispatch();
    const [product, setProduct] = useState({name: '', desc: '', pret: 0});
    const setProductName = (name) => {
        let newProduct = product;

        newProduct.name = name;
        console.log(newProduct)
        setProduct(newProduct);
    }
    const setProductDesc = (desc) => {
        let newProduct = product;
        newProduct.desc = desc;
        setProduct(newProduct);
    }
    const setProductPret = (pret) => {
        let newProduct = product;
        newProduct.pret = pret;
        setProduct(newProduct);
    }

    const addProduct = () => {
        dispatch(add_product(product));
    }

    return (
        <div className='d-flex justify-content-center align-items-center flex-column'>
            <TextField className='mb-3' onChange={(e) => setProductName(e.target.value)} value={product.name} id="outlined-basic" label="Produs" variant="outlined" />
            <TextField className='mb-3' onChange={(e) => setProductDesc(e.target.value)} value={product.desc} id="outlined-basic" label="Descriere" variant="outlined" />
            <TextField className='mb-3' onChange={(e) => setProductPret(e.target.value)} value={product.pret} id="outlined-basic" label="Pret" variant="outlined" />
            <Button onClick={() => addProduct()} variant="contained">Adaugare</Button>
        </div>
    )
}

export default InsertForm;