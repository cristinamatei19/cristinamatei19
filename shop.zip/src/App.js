import './App.css';
import Main from './Pages/Main';
import Auth from './Pages/Auth';
import User from './Pages/User';
import { useSelector } from 'react-redux';

function App() {
  const isLogged = useSelector((state) => state.auth.isLogged);
  const page = useSelector((state) => state.page.page)
  return (
    <div className="App">

        {!isLogged ?
          <div id='AppDiv' className="App-div justify-content-center">
            <Auth />
          </div>
          :
          page === 1 ?
          <div id='AppDiv' className="App-div">
            <Main />
          </div>
          : page === 2 ?
          <div id='AppDiv' className="App-div">
            <User />
          </div> : ""
          }
    </div>
  );
}

export default App;
