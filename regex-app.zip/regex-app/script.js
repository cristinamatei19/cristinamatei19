
function validate(){
    var phoneNumber = document.getElementById('phone-number').value;
    var postalCode = document.getElementById('postal-code').value;

    // var phoneRoRGEX = ...;
    // var postalRGEX = ...;
    var phoneResult = phoneRoRGEX.test(phoneNumber);
    var postalResult = postalRGEX.test(postalCode);
    alert("phone:"+phoneResult + ", postal code: "+postalResult);

    return false;
}