import { createSlice } from '@reduxjs/toolkit'

export const authSlice = createSlice({
  name: 'auth',
  initialState: {
    isLogged: false,
    username: 'admin',
    password: 'admin'
  },
  reducers: {
    log_in: (state, action) => {
        if(action.payload.username === state.username && action.payload.password === state.password) {
            state.isLogged = true;
            return 1;
        } else return 0;
    }
  },
})

export const { log_in } = authSlice.actions

export default authSlice.reducer