import './Content.css';

const Content = () => {
    return (
        <>
        </>
    )
}

export default Content;