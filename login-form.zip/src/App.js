import './App.css';
import Main from './Pages/Main';
import Auth from './Pages/Auth';

function App() {
  return (
    <div className="App">
      <div className="App-div">
          
      </div>
    </div>
  );
}

export default App;
